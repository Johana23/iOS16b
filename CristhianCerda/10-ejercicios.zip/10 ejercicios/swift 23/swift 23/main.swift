//
//  main.swift
//  swift 23
//
//  Created by user on 10/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation

func input() ->NSString {
    var keyboard = NSFileHandle.fileHandleWithStandardInput()
    var inputData = keyboard.availableData
    return NSString(data: inputData, encoding:NSUTF8StringEncoding)!
}

println("Ingresa el numero")
var num1 = input()
var limite = num1.integerValue
var resultado = 1

for var suma=1; suma<=limite; ++suma{
    var total = suma
    
    if (total % 2 == 0)
    {
    println("Numero par: \(total)")
    resultado = resultado *  total
 
}
}
println("Multiplicacion: \(resultado)")