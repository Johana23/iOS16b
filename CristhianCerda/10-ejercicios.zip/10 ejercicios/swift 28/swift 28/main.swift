//
//  main.swift
//  swift 28
//
//  Created by user on 10/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation


println("Suma de Raiz Cuadrada")

var resultado = 0

for var suma=1; suma<=1000; ++suma{
    var total = suma
    var total2 = Double(suma)
    var rai = sqrt(total2)
    var rai2 = Int(rai)
    if (total % 2 == 0){
    }else{
        println("Numero Impar:\(total) X^2:\(rai)")
        resultado = resultado + rai2
    }
}
println("Suma de los numeros Pares al Cuadrado:\(resultado)")