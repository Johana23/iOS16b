//
//  main.swift
//  swift 29
//
//  Created by user on 10/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation


func input() ->NSString {
    var keyboard = NSFileHandle.fileHandleWithStandardInput()
    var inputData = keyboard.availableData
    return NSString(data: inputData, encoding:NSUTF8StringEncoding)!
}

println("Ingresa tu Cantidad en dolares")
var num1 = input()
var resultado = num1.doubleValue * 4
var resultado2 = num1.doubleValue * 100
var resultado3 = num1.doubleValue * 20
var resultado4 = num1.doubleValue * 10
var resultado5 = num1.doubleValue * 1

println("Tienes:\(resultado2) Monedas de 1 Centavos Americanos")
println("Tienes:\(resultado3) Monedas de 5 Centavos Americanos")
println("Tienes:\(resultado4) Monedas de 10 Centavos Americanos")
println("Tienes:\(resultado) Monedas de 25 Centavos Americanos")
println("Tienes:\(resultado5) Monedas de 1 Dolar Americano")


