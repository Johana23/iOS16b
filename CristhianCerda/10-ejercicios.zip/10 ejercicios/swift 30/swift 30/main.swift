//
//  main.swift
//  swift 30
//
//  Created by user on 10/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation

func input() ->NSString {
    var keyboard = NSFileHandle.fileHandleWithStandardInput()
    var inputData = keyboard.availableData
    return NSString(data: inputData, encoding:NSUTF8StringEncoding)!
}

println("Convertir de Libras a Dolares")
println("Ingresa la Cantidad a Convertir")
var ld = input()
var li = ld.floatValue
var dolar : Float = 2.80
var resultado = li * dolar
println("$\(resultado)0 Dlls")