//
//  main.swift
//  swift 25
//
//  Created by user on 10/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation

func input() ->NSString {
    var keyboard = NSFileHandle.fileHandleWithStandardInput()
    var inputData = keyboard.availableData
    return NSString(data: inputData, encoding:NSUTF8StringEncoding)!
}

println("Ingresa el numero")
var num1 = input()
var limite = num1.integerValue
println("Numero   Potencia cuarta")

for var suma=1; suma<=limite; ++suma{
    var total = suma
    var total2 = Double(suma)
    var expo = pow(total2, 4)
    
    if(limite <= 50){
        
        println("\(total)         \(expo)")
    }
}
if (limite > 50){
    println("Fuera de Rango")
}

