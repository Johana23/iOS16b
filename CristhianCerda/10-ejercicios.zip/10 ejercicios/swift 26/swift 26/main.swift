//
//  main.swift
//  swift 26
//
//  Created by user on 10/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation

println("Raiz Cuadrada del 100 al 120")

for var suma=100; suma<=120; ++suma{
    
    var total = suma
    var totald = Double(suma)
    var sq = sqrt(totald)
    println("Resultado:\(total)   Raiz:\(sq)")
}


