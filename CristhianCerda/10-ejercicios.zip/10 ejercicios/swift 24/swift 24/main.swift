//
//  main.swift
//  swift 24
//
//  Created by user on 10/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation

func input() ->NSString {
    var keyboard = NSFileHandle.fileHandleWithStandardInput()
    var inputData = keyboard.availableData
    return NSString(data: inputData, encoding:NSUTF8StringEncoding)!
}

println("Ingresa el numero")
var num1 = input()
var limite = num1.integerValue

for var suma=1; suma<=limite; ++suma{
    var total = suma
    var total2 = Double(suma)
    var expo = pow(total2, 2)
    
    if(limite <= 30){
        println("Numero: \(total) Numero al Cuadrado: \(expo)")
}
}
if (limite > 30){
  println("Fuera de Rango")
}

