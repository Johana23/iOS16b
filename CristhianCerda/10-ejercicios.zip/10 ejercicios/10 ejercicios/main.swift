//
//  main.swift
//  10 ejercicios
//
//  Created by user on 09/11/16.
//  Copyright (c) 2016 cris. All rights reserved.
//

import Foundation

//metodo para leer de teclado
func input() ->NSString {
    var keyboard = NSFileHandle.fileHandleWithStandardInput()
    var inputData = keyboard.availableData
    return NSString(data: inputData, encoding:NSUTF8StringEncoding)!
}


println("Ingresa el valor del numero 1")
var num1 = input()
println("Ingresa el valor del numero 2")
var num2 = input()

var resultado = num1.integerValue + num2.integerValue

if(resultado > 0) {
  println("El Resultado es Positivo: \(resultado)")
}
else if (resultado < 0)
{
println("El Resultado es Negativo: \(resultado)")
}else{
   println("Resultado igual a Cero: \(resultado)")
}


