//
//  ArticulosData.swift
//  Tienda
//
//  Created by Juan Carlos Salazar Mesa on 29/11/15.
//  Copyright © 2015 Juan Carlos Salazar Mesa. All rights reserved.
//

import UIKit

class ArticulosData: NSObject {
    
    var idArticulo: String = String()
    var dsArticulo: String = String()
    var valArticulo: String = String()
    var exitArticulo: String = String()
}
