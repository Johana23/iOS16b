//
//  Tienda-Bridging-Header.h
//  Tienda
//
//  Created by Juan Carlos Salazar Mesa on 29/11/15.
//  Copyright © 2015 Juan Carlos Salazar Mesa. All rights reserved.
//

#ifndef Tienda_Bridging_Header_h
#define Tienda_Bridging_Header_h


#endif /* Tienda_Bridging_Header_h */
#import "FMDatabase.h"
