//
//  BdViewController.h
//  Swift
//
//  Created by isc on 28/11/16.
//  Copyright © 2016 Gonzalez Silvia. All rights reserved.


//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface BdViewController : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate>
{
    IBOutlet UIPickerView *picker;
    AppDelegate *mainDelegate;
    
}

@property(nonatomic, strong) IBOutlet UIPickerView *picker;
@property(nonatomic, strong) AppDelegate *mainDelegate;


@end
