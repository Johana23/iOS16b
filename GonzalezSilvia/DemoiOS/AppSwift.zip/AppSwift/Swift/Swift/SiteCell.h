//
//  SiteCell.h
//  AppDemo
//
//  Created by isc on 28/11/16.
//  Copyright © 2016 Gonzalez Silvia. All rights reserved.

//

#import <UIKit/UIKit.h>

@interface SiteCell : UITableViewCell

{
    UILabel *primerLabel;
    UILabel *segundoLabel;
    UIImageView *myImageView;
}
@property (nonatomic, strong) UILabel *primerLabel;
@property (nonatomic, strong) UILabel *segundoLabel;
@property (nonatomic, strong) UIImageView *myImageView;
@end
